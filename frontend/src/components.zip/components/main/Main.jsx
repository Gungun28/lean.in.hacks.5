import React from 'react'
import './Main.scss'
const Main = () => {
  return (
    <div className='main'>
      <div className="first">
        <span>JEWLLERY</span>
      </div>
      <div className="sec">
        <span>PHONE CASE</span>
      </div>
      <div className="last">
        <span>PURSES </span>
      </div>
    </div>
  )
}

export default Main